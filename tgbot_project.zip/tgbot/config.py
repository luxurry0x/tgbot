"""
config.py - إعدادات البوت الرئيسية
"""

import os

# ===== إعدادات البوت =====
BOT_TOKEN = os.getenv("BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")
ADMIN_ID = int(os.getenv("ADMIN_ID", "123456789"))  # ضع ID الأدمن هنا

# ===== مسارات الملفات =====
DATA_FILE = os.getenv("DATA_FILE", "/data/bigfile.txt")      # ملف البيانات الكبير
RAMDISK_PATH = os.getenv("RAMDISK_PATH", "/mnt/ramdisk")     # مسار الـ RAM Disk (اختياري)
DB_PATH = os.getenv("DB_PATH", "bot_database.db")            # قاعدة البيانات

# ===== حدود البحث =====
FREE_RESULTS_LIMIT = 1000        # الحد الأقصى للمستخدمين المجانيين
PREMIUM_RESULTS_LIMIT = None     # بلا حدود للمستخدمين المميزين

# ===== أداء البحث =====
SEARCH_TIMEOUT = 60              # مهلة البحث بالثواني
USE_RIPGREP = True               # استخدام ripgrep إن كان متاحاً (أسرع)
MAX_CONCURRENT_SEARCHES = 10    # الحد الأقصى للبحوث المتزامنة

# ===== مكافحة الإساءة =====
SEARCH_COOLDOWN = 5              # ثواني بين كل بحث وآخر
MAX_QUERY_LENGTH = 200           # الحد الأقصى لطول نص البحث

# ===== رسائل البوت =====
WELCOME_MSG = """
🔍 *مرحباً بك في بوت البحث الاحترافي*

يمكنك البحث في قاعدة بيانات ضخمة بسرعة عالية.

📌 *حسابك:* مجاني
🔎 *الحد الأقصى للنتائج:* {limit} نتيجة

استخدم الأزرار أدناه للبدء 👇
"""
