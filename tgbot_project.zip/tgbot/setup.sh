#!/bin/bash
# setup.sh - سكريبت الإعداد التلقائي على VPS

set -e
echo "🚀 إعداد بوت البحث على VPS..."

# ===== 1. تثبيت المتطلبات =====
echo "📦 تثبيت المتطلبات النظامية..."
sudo apt-get update -q
sudo apt-get install -y python3 python3-pip python3-venv ripgrep

# التحقق من ripgrep
if command -v rg &> /dev/null; then
    echo "✅ ripgrep مثبّت: $(rg --version | head -1)"
else
    echo "⚠️ ripgrep غير متاح، سيتم استخدام grep"
fi

# ===== 2. نسخ الملفات =====
echo "📁 إعداد مجلد المشروع..."
sudo mkdir -p /opt/tgbot
sudo cp -r ./* /opt/tgbot/
sudo chown -R ubuntu:ubuntu /opt/tgbot

# ===== 3. البيئة الافتراضية =====
echo "🐍 إنشاء بيئة Python افتراضية..."
cd /opt/tgbot
python3 -m venv venv
venv/bin/pip install --upgrade pip -q
venv/bin/pip install -r requirements.txt -q
echo "✅ المكتبات مثبّتة"

# ===== 4. RAM Disk (اختياري - لأداء أقصى) =====
echo ""
echo "💡 هل تريد إعداد RAM Disk لأداء أقصى؟ (يوصى به للملفات +5GB)"
echo "   سيتم تخصيص 12GB من الرام للملف"
read -p "إعداد RAM Disk؟ [y/N]: " setup_ramdisk

if [[ "$setup_ramdisk" =~ ^[Yy]$ ]]; then
    sudo mkdir -p /mnt/ramdisk
    sudo mount -t tmpfs -o size=12g tmpfs /mnt/ramdisk
    # إضافة للـ fstab لتثبيته بعد إعادة التشغيل
    echo "tmpfs /mnt/ramdisk tmpfs size=12g,noatime 0 0" | sudo tee -a /etc/fstab
    echo "✅ RAM Disk جاهز على /mnt/ramdisk"
    echo "⚠️  انسخ ملف bigfile.txt إلى /mnt/ramdisk/bigfile.txt للاستفادة منه"
fi

# ===== 5. خدمة systemd =====
echo ""
echo "⚙️ إعداد خدمة systemd..."
read -p "أدخل BOT_TOKEN: " bot_token
read -p "أدخل ADMIN_ID (رقمي): " admin_id
read -p "مسار ملف البيانات [/data/bigfile.txt]: " data_file
data_file=${data_file:-/data/bigfile.txt}

sed -i "s|YOUR_TOKEN_HERE|$bot_token|g" /opt/tgbot/tgbot.service
sed -i "s|YOUR_ADMIN_ID|$admin_id|g" /opt/tgbot/tgbot.service
sed -i "s|/data/bigfile.txt|$data_file|g" /opt/tgbot/tgbot.service

sudo cp /opt/tgbot/tgbot.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable tgbot
sudo systemctl start tgbot

echo ""
echo "✅ ============================================"
echo "   البوت يعمل الآن!"
echo "============================================"
echo ""
echo "أوامر مفيدة:"
echo "  sudo systemctl status tgbot     # حالة البوت"
echo "  sudo systemctl restart tgbot    # إعادة التشغيل"
echo "  sudo journalctl -u tgbot -f     # السجلات المباشرة"
echo "  tail -f /var/log/tgbot.log      # سجلات الملف"
