"""
handlers/admin_handlers.py - لوحة تحكم الأدمن الكاملة
"""

import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from telegram.constants import ParseMode

from config import ADMIN_ID
from core.database import (
    get_stats, get_all_users, get_user,
    set_user_status, get_user_search_count_today
)
from core.search_engine import get_file_info
from utils.keyboards import admin_panel_menu, back_to_admin, back_to_main
from utils.helpers import format_number, format_duration

logger = logging.getLogger(__name__)

# حالات إدخال الأدمن
ADMIN_PROMOTE  = "admin_promote"
ADMIN_DEMOTE   = "admin_demote"
ADMIN_BAN      = "admin_ban"
ADMIN_UNBAN    = "admin_unban"


def _is_admin(tg_id: int) -> bool:
    return tg_id == ADMIN_ID


async def show_admin_panel(query):
    """عرض لوحة تحكم الأدمن"""
    stats = get_stats()
    text = (
        "🛠 *لوحة تحكم الأدمن*\n\n"
        f"👥 المستخدمون الكلي: {format_number(stats['total_users'])}\n"
        f"⭐ المميزون: {format_number(stats['premium_users'])}\n"
        f"🚫 المحظورون: {format_number(stats['banned_users'])}\n"
        f"🔍 بحوث اليوم: {format_number(stats['today_searches'])}\n\n"
        "اختر إجراءً 👇"
    )
    await query.edit_message_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=admin_panel_menu())


async def handle_admin_callback(update: Update, context: ContextTypes.DEFAULT_TYPE, data: str):
    """معالجة أزرار الأدمن"""
    query  = update.callback_query
    tg_id  = query.from_user.id

    if not _is_admin(tg_id):
        await query.answer("⛔ غير مصرح.", show_alert=True)
        return

    if data == "admin_panel":
        await show_admin_panel(query)

    elif data == "admin_users_count":
        await _show_users_count(query)

    elif data == "admin_users_list":
        await _show_users_list(query)

    elif data == "admin_file_info":
        await _show_file_info(query)

    elif data == "admin_search_stats":
        await _show_search_stats(query)

    elif data == "admin_promote":
        context.user_data["admin_state"] = ADMIN_PROMOTE
        await query.edit_message_text(
            "⭐ *ترقية مستخدم*\n\nأرسل ID التيليغرام للمستخدم المراد ترقيته:",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=back_to_admin()
        )

    elif data == "admin_demote":
        context.user_data["admin_state"] = ADMIN_DEMOTE
        await query.edit_message_text(
            "🔽 *إلغاء الترقية*\n\nأرسل ID التيليغرام للمستخدم:",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=back_to_admin()
        )

    elif data == "admin_ban":
        context.user_data["admin_state"] = ADMIN_BAN
        await query.edit_message_text(
            "🚫 *حظر مستخدم*\n\nأرسل ID التيليغرام للمستخدم:",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=back_to_admin()
        )

    elif data == "admin_unban":
        context.user_data["admin_state"] = ADMIN_UNBAN
        await query.edit_message_text(
            "✅ *رفع الحظر*\n\nأرسل ID التيليغرام للمستخدم:",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=back_to_admin()
        )


async def handle_admin_input(update: Update, context: ContextTypes.DEFAULT_TYPE, state: str, text: str):
    """معالجة المدخلات النصية لأوامر الأدمن"""
    tg_id = update.effective_user.id

    if not _is_admin(tg_id):
        return

    context.user_data.pop("admin_state", None)

    # التحقق من أن المدخل رقم صحيح
    try:
        target_id = int(text.strip())
    except ValueError:
        await update.message.reply_text(
            "❌ يجب إرسال ID رقمي صحيح.",
            reply_markup=back_to_admin()
        )
        return

    # لا يمكن تعديل الأدمن نفسه
    if target_id == ADMIN_ID:
        await update.message.reply_text("⚠️ لا يمكن تعديل حساب الأدمن.", reply_markup=back_to_admin())
        return

    user = get_user(target_id)
    if not user:
        await update.message.reply_text(
            f"❌ لم يُعثر على مستخدم بـ ID: `{target_id}`",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=back_to_admin()
        )
        return

    action_map = {
        ADMIN_PROMOTE: ("premium", "⭐ تمت الترقية إلى مميز"),
        ADMIN_DEMOTE:  ("free",    "🔽 تم إلغاء الترقية"),
        ADMIN_BAN:     ("banned",  "🚫 تم الحظر"),
        ADMIN_UNBAN:   ("free",    "✅ تم رفع الحظر"),
    }

    if state not in action_map:
        return

    new_status, action_text = action_map[state]
    success = set_user_status(target_id, new_status)

    if success:
        name = user.get("full_name") or str(target_id)
        await update.message.reply_text(
            f"{action_text}\n\n"
            f"👤 المستخدم: {name}\n"
            f"🆔 ID: `{target_id}`\n"
            f"📌 الحالة الجديدة: {new_status}",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=back_to_admin()
        )
    else:
        await update.message.reply_text("❌ فشل تنفيذ الإجراء.", reply_markup=back_to_admin())


async def _show_users_count(query):
    stats = get_stats()
    text = (
        "👥 *إحصائيات المستخدمين*\n\n"
        f"📊 الإجمالي: {format_number(stats['total_users'])}\n"
        f"🆓 مجانيون: {format_number(stats['free_users'])}\n"
        f"⭐ مميزون: {format_number(stats['premium_users'])}\n"
        f"🚫 محظورون: {format_number(stats['banned_users'])}\n\n"
        f"🔍 بحوث اليوم: {format_number(stats['today_searches'])}\n"
        f"🔢 إجمالي البحوث: {format_number(stats['total_searches'])}"
    )
    await query.edit_message_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=back_to_admin())


async def _show_users_list(query):
    users = get_all_users(limit=20)
    if not users:
        await query.edit_message_text("لا يوجد مستخدمون.", reply_markup=back_to_admin())
        return

    lines = ["📋 *آخر 20 مستخدم:*\n"]
    status_emoji = {"free": "🆓", "premium": "⭐", "banned": "🚫"}

    for u in users:
        emoji = status_emoji.get(u["status"], "❓")
        name  = (u["full_name"] or "مجهول")[:20]
        lines.append(f"{emoji} `{u['telegram_id']}` - {name} ({u['search_count']} بحث)")

    await query.edit_message_text(
        "\n".join(lines),
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=back_to_admin()
    )


async def _show_file_info(query):
    info = get_file_info()
    if not info["exists"]:
        text = f"❌ *الملف غير موجود*\n\nالمسار: `{info['path']}`"
    else:
        text = (
            f"📁 *معلومات ملف البيانات*\n\n"
            f"📂 المسار: `{info['path']}`\n"
            f"💾 الحجم: {info['size_human']}\n"
            f"🛠 أداة البحث: {info['search_tool']}\n"
            f"⚡ RAM Disk: {'✅ مفعّل' if info.get('ramdisk_active') else '❌ معطّل'}"
        )
    await query.edit_message_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=back_to_admin())


async def _show_search_stats(query):
    stats = get_stats()
    text = (
        f"📈 *إحصائيات البحث*\n\n"
        f"🔢 إجمالي البحوث: {format_number(stats['total_searches'])}\n"
        f"📅 بحوث اليوم: {format_number(stats['today_searches'])}\n"
        f"⚡ متوسط الاستجابة (24س): {format_duration(int(stats['avg_search_ms']))}"
    )
    await query.edit_message_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=back_to_admin())
