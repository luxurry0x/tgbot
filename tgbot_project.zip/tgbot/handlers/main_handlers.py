"""
handlers/main_handlers.py - معالجات الأوامر والأزرار الرئيسية
"""

import os
import logging
from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode

from config import ADMIN_ID, FREE_RESULTS_LIMIT
from core.database import get_or_create_user, get_stats, log_search
from core.search_engine import search_in_file, write_results_to_file, get_file_info
from utils.keyboards import main_menu, back_to_main, cancel_keyboard, search_again_keyboard
from utils.helpers import check_cooldown, validate_query, format_number, format_duration

logger = logging.getLogger(__name__)

# ===== حالات المحادثة =====
WAITING_SEARCH = "waiting_search"


def _get_user_info(update: Update) -> tuple[int, str, str]:
    user = update.effective_user
    return user.id, user.username or "", user.full_name or "مجهول"


async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """أمر /start - الترحيب وتسجيل المستخدم"""
    tg_id, username, full_name = _get_user_info(update)
    user = get_or_create_user(tg_id, username, full_name)

    is_admin   = tg_id == ADMIN_ID
    is_premium = user["status"] == "premium"
    is_banned  = user["status"] == "banned"

    if is_banned:
        await update.message.reply_text("🚫 أنت محظور من استخدام هذا البوت.")
        return

    limit_text = "بلا حدود ♾️" if is_premium else format_number(FREE_RESULTS_LIMIT)
    badge = "⭐ مميز" if is_premium else "🆓 مجاني"

    text = (
        f"👋 *مرحباً {full_name}!*\n\n"
        f"🔍 *بوت البحث الاحترافي*\n"
        f"ابحث في قاعدة بيانات ضخمة بسرعة عالية\n\n"
        f"👤 حسابك: {badge}\n"
        f"🔎 الحد الأقصى للنتائج: {limit_text}\n\n"
        f"اختر من القائمة أدناه 👇"
    )

    await update.message.reply_text(
        text,
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=main_menu(is_admin=is_admin, is_premium=is_premium)
    )


async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """مُعالج مركزي لجميع أزرار Inline"""
    query = update.callback_query
    await query.answer()

    tg_id = query.from_user.id
    data  = query.data

    user = get_or_create_user(tg_id, query.from_user.username, query.from_user.full_name)

    if user["status"] == "banned" and data != "main_menu":
        await query.edit_message_text("🚫 أنت محظور من استخدام هذا البوت.")
        return

    is_admin   = tg_id == ADMIN_ID
    is_premium = user["status"] == "premium"

    # ===== توجيه الأزرار =====
    if data == "main_menu":
        limit_text = "بلا حدود ♾️" if is_premium else format_number(FREE_RESULTS_LIMIT)
        badge = "⭐ مميز" if is_premium else "🆓 مجاني"
        text = (
            f"🏠 *القائمة الرئيسية*\n\n"
            f"👤 حسابك: {badge}\n"
            f"🔎 الحد الأقصى: {limit_text}\n\n"
            f"اختر ما تريد 👇"
        )
        await query.edit_message_text(
            text, parse_mode=ParseMode.MARKDOWN,
            reply_markup=main_menu(is_admin=is_admin, is_premium=is_premium)
        )

    elif data == "search":
        context.user_data["state"] = WAITING_SEARCH
        await query.edit_message_text(
            "🔍 *وضع البحث*\n\n"
            "✏️ أرسل الآن نص البحث...\n\n"
            "💡 _مثال: محمد أحمد_",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=cancel_keyboard()
        )

    elif data == "my_account":
        await show_account(query, user, is_premium)

    elif data == "stats":
        await show_public_stats(query)

    elif data == "premium_info":
        await show_premium_info(query, is_premium)

    elif data == "admin_panel" and is_admin:
        from handlers.admin_handlers import show_admin_panel
        await show_admin_panel(query)

    elif data.startswith("admin_") and is_admin:
        from handlers.admin_handlers import handle_admin_callback
        await handle_admin_callback(update, context, data)

    elif data.startswith("admin_") and not is_admin:
        await query.answer("⛔ غير مصرح لك بهذا الإجراء.", show_alert=True)


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """معالجة الرسائل النصية - خاصةً طلبات البحث"""
    tg_id    = update.effective_user.id
    text     = update.message.text or ""
    user     = get_or_create_user(tg_id, update.effective_user.username, update.effective_user.full_name)

    if user["status"] == "banned":
        await update.message.reply_text("🚫 أنت محظور من استخدام هذا البوت.")
        return

    state = context.user_data.get("state")

    # ===== حالة انتظار نص البحث =====
    if state == WAITING_SEARCH:
        await _perform_search(update, context, text, user)
        return

    # ===== حالات الأدمن =====
    admin_state = context.user_data.get("admin_state")
    if admin_state and tg_id == ADMIN_ID:
        from handlers.admin_handlers import handle_admin_input
        await handle_admin_input(update, context, admin_state, text)
        return

    # ===== رسالة عادية =====
    await update.message.reply_text(
        "👋 استخدم الأزرار أدناه للتنقل.\n"
        "أو اكتب /start للبدء من جديد.",
        reply_markup=main_menu(is_admin=(tg_id == ADMIN_ID), is_premium=(user["status"] == "premium"))
    )


async def _perform_search(update: Update, context: ContextTypes.DEFAULT_TYPE, query_text: str, user: dict):
    """تنفيذ البحث الفعلي وإرسال النتائج"""
    tg_id      = update.effective_user.id
    is_premium = user["status"] == "premium"

    context.user_data.pop("state", None)

    # فحص مهلة الانتظار (anti-spam)
    remaining = check_cooldown(tg_id)
    if remaining > 0:
        await update.message.reply_text(
            f"⏳ الرجاء الانتظار {remaining} ثانية قبل البحث مجدداً.",
            reply_markup=cancel_keyboard()
        )
        return

    # التحقق من صحة نص البحث
    valid, error_msg = validate_query(query_text)
    if not valid:
        await update.message.reply_text(error_msg, reply_markup=cancel_keyboard())
        return

    # رسالة الانتظار
    wait_msg = await update.message.reply_text(
        f"🔍 جارٍ البحث عن: *{query_text}*\n\n⏳ الرجاء الانتظار...",
        parse_mode=ParseMode.MARKDOWN
    )

    # تنفيذ البحث
    result = await search_in_file(query_text, is_premium=is_premium)

    # تسجيل البحث في قاعدة البيانات
    log_search(tg_id, query_text, result.get("count", 0), result.get("duration_ms", 0))

    # حذف رسالة الانتظار
    try:
        await wait_msg.delete()
    except Exception:
        pass

    # إذا كان هناك خطأ
    if result.get("error"):
        await update.message.reply_text(
            f"❌ *خطأ في البحث*\n\n{result['error']}",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=search_again_keyboard()
        )
        return

    count    = result["count"]
    duration = format_duration(result["duration_ms"])
    tool     = result.get("tool_used", "unknown")
    truncated = result.get("truncated", False)

    # لا توجد نتائج
    if count == 0:
        await update.message.reply_text(
            f"🔍 البحث عن: *{query_text}*\n\n"
            f"😔 لم يُعثر على أي نتائج.\n"
            f"⏱ الوقت: {duration}",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=search_again_keyboard()
        )
        return

    # إرسال النتائج كملف TXT
    file_path = await write_results_to_file(result["results"], query_text)

    caption = (
        f"✅ *نتائج البحث*\n\n"
        f"🔎 الكلمة: `{query_text}`\n"
        f"📊 النتائج: {format_number(count)}"
        f"{' (مُقيَّد)' if truncated else ''}\n"
        f"⏱ الوقت: {duration}\n"
        f"🛠 الأداة: {tool}"
    )

    if truncated and not is_premium:
        caption += (
            f"\n\n⚠️ *تم تقييد النتائج إلى {format_number(FREE_RESULTS_LIMIT)}*\n"
            f"للحصول على نتائج غير محدودة، انضم للخطة المميزة! ⭐"
        )

    try:
        with open(file_path, "rb") as f:
            await update.message.reply_document(
                document=f,
                filename=f"results_{query_text[:30]}.txt",
                caption=caption,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=search_again_keyboard()
            )
    finally:
        os.unlink(file_path)  # حذف الملف المؤقت فوراً بعد الإرسال


async def show_account(query, user: dict, is_premium: bool):
    """عرض معلومات حساب المستخدم"""
    badge = "⭐ مميز" if is_premium else "🆓 مجاني"
    limit = "بلا حدود ♾️" if is_premium else format_number(FREE_RESULTS_LIMIT)

    text = (
        f"👤 *معلومات حسابك*\n\n"
        f"🆔 المعرف: `{user['telegram_id']}`\n"
        f"📛 الاسم: {user['full_name'] or 'غير محدد'}\n"
        f"🏷 الحالة: {badge}\n"
        f"🔎 الحد الأقصى: {limit}\n"
        f"🔢 إجمالي البحوث: {format_number(user['search_count'])}\n"
        f"📅 تاريخ الانضمام: {(user['joined_at'] or '')[:10]}\n"
        f"⏰ آخر بحث: {(user['last_search'] or 'لم يبحث بعد')[:16]}"
    )
    await query.edit_message_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=back_to_main())


async def show_public_stats(query):
    """عرض إحصائيات عامة"""
    stats = get_stats()
    file_info = get_file_info()

    file_size = file_info.get("size_human", "غير معروف") if file_info["exists"] else "الملف غير موجود"

    text = (
        f"📊 *إحصائيات البوت*\n\n"
        f"👥 المستخدمون: {format_number(stats['total_users'])}\n"
        f"⭐ المميزون: {format_number(stats['premium_users'])}\n"
        f"🔍 إجمالي البحوث: {format_number(stats['total_searches'])}\n"
        f"📅 بحوث اليوم: {format_number(stats['today_searches'])}\n"
        f"⚡ متوسط سرعة البحث: {format_duration(int(stats['avg_search_ms']))}\n"
        f"📁 حجم قاعدة البيانات: {file_size}"
    )
    await query.edit_message_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=back_to_main())


async def show_premium_info(query, is_premium: bool):
    """عرض معلومات الاشتراك المميز"""
    if is_premium:
        text = (
            "⭐ *أنت بالفعل مستخدم مميز!*\n\n"
            "✅ نتائج بحث غير محدودة\n"
            "✅ أولوية في البحث\n"
            "✅ دعم فني متقدم\n\n"
            "شكراً لدعمك! 🙏"
        )
    else:
        text = (
            "⭐ *الخطة المميزة*\n\n"
            "🆓 *المجاني:*\n"
            f"• حد {format_number(FREE_RESULTS_LIMIT)} نتيجة\n"
            "• بحث عادي\n\n"
            "⭐ *المميز:*\n"
            "• نتائج غير محدودة ♾️\n"
            "• أولوية في الاستجابة\n"
            "• دعم متقدم\n\n"
            "📩 للترقية: تواصل مع الأدمن"
        )
    await query.edit_message_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=back_to_main())
