"""
utils/helpers.py - أدوات مساعدة: مكافحة السبام، التحقق من المدخلات
"""

import time
import logging
import re
from config import SEARCH_COOLDOWN, MAX_QUERY_LENGTH

logger = logging.getLogger(__name__)

# ===== مكافحة السبام =====
# {telegram_id: last_search_timestamp}
_last_search: dict[int, float] = {}

# حروف ممنوعة في الأوامر للحماية من حقن الأوامر
_DANGEROUS_PATTERN = re.compile(r'[`$\\|><;&\n\r]')


def check_cooldown(telegram_id: int) -> float:
    """
    فحص مهلة الانتظار بين البحوث.
    Returns: 0 إذا مسموح، وإلا عدد الثواني المتبقية
    """
    now = time.time()
    last = _last_search.get(telegram_id, 0)
    elapsed = now - last
    remaining = SEARCH_COOLDOWN - elapsed

    if remaining > 0:
        return round(remaining, 1)

    _last_search[telegram_id] = now
    return 0


def validate_query(query: str) -> tuple[bool, str]:
    """
    التحقق من نص البحث.
    Returns: (صالح, رسالة الخطأ)
    """
    query = query.strip()

    if not query:
        return False, "❌ نص البحث فارغ."

    if len(query) > MAX_QUERY_LENGTH:
        return False, f"❌ نص البحث طويل جداً (الحد: {MAX_QUERY_LENGTH} حرف)."

    if len(query) < 2:
        return False, "❌ نص البحث قصير جداً (2 أحرف على الأقل)."

    if _DANGEROUS_PATTERN.search(query):
        return False, "❌ يحتوي نص البحث على أحرف غير مسموح بها."

    return True, ""


def sanitize_query(query: str) -> str:
    """تنظيف نص البحث من الأحرف الخطرة"""
    return _DANGEROUS_PATTERN.sub("", query).strip()


def format_number(n: int) -> str:
    """تنسيق الأرقام الكبيرة (1000 → 1,000)"""
    return f"{n:,}"


def format_duration(ms: int) -> str:
    """تحويل الميلي ثانية لنص مقروء"""
    if ms < 1000:
        return f"{ms}ms"
    return f"{ms/1000:.1f}s"


def escape_md(text: str) -> str:
    """Escape خاص لـ MarkdownV2 في تيليغرام"""
    chars = r'\_*[]()~`>#+-=|{}.!'
    for c in chars:
        text = text.replace(c, f"\\{c}")
    return text
