"""
utils/keyboards.py - أزرار Inline Keyboard لواجهة البوت
"""

from telegram import InlineKeyboardButton, InlineKeyboardMarkup


def main_menu(is_admin: bool = False, is_premium: bool = False) -> InlineKeyboardMarkup:
    """القائمة الرئيسية"""
    rows = [
        [InlineKeyboardButton("🔍 بحث", callback_data="search"),
         InlineKeyboardButton("⭐ المميزين", callback_data="premium_info")],
        [InlineKeyboardButton("📊 الإحصائيات", callback_data="stats"),
         InlineKeyboardButton("👤 حسابي", callback_data="my_account")],
    ]
    if is_admin:
        rows.append([InlineKeyboardButton("🛠 لوحة الأدمن", callback_data="admin_panel")])
    return InlineKeyboardMarkup(rows)


def admin_panel_menu() -> InlineKeyboardMarkup:
    """لوحة تحكم الأدمن"""
    rows = [
        [InlineKeyboardButton("👥 عدد المستخدمين", callback_data="admin_users_count"),
         InlineKeyboardButton("📋 قائمة المستخدمين", callback_data="admin_users_list")],
        [InlineKeyboardButton("⭐ ترقية مستخدم", callback_data="admin_promote"),
         InlineKeyboardButton("🔽 إلغاء الترقية", callback_data="admin_demote")],
        [InlineKeyboardButton("🚫 حظر مستخدم", callback_data="admin_ban"),
         InlineKeyboardButton("✅ رفع الحظر", callback_data="admin_unban")],
        [InlineKeyboardButton("📁 معلومات الملف", callback_data="admin_file_info"),
         InlineKeyboardButton("📈 إحصائيات البحث", callback_data="admin_search_stats")],
        [InlineKeyboardButton("🔙 القائمة الرئيسية", callback_data="main_menu")],
    ]
    return InlineKeyboardMarkup(rows)


def back_to_main() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔙 رجوع", callback_data="main_menu")]
    ])


def back_to_admin() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔙 لوحة الأدمن", callback_data="admin_panel"),
         InlineKeyboardButton("🏠 الرئيسية", callback_data="main_menu")]
    ])


def cancel_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("❌ إلغاء", callback_data="main_menu")]
    ])


def search_again_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔍 بحث مجدداً", callback_data="search"),
         InlineKeyboardButton("🏠 الرئيسية", callback_data="main_menu")]
    ])
