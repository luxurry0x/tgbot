"""
core/database.py - إدارة قاعدة البيانات SQLite
"""

import sqlite3
import logging
from datetime import datetime
from contextlib import contextmanager
from config import DB_PATH

logger = logging.getLogger(__name__)


@contextmanager
def get_db():
    """Context manager للاتصال الآمن بقاعدة البيانات"""
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")   # أداء أفضل للكتابة المتزامنة
    conn.execute("PRAGMA synchronous=NORMAL")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    """إنشاء جداول قاعدة البيانات عند أول تشغيل"""
    with get_db() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                id              INTEGER PRIMARY KEY,
                telegram_id     INTEGER UNIQUE NOT NULL,
                username        TEXT,
                full_name       TEXT,
                status          TEXT DEFAULT 'free'  CHECK(status IN ('free','premium','banned')),
                search_count    INTEGER DEFAULT 0,
                last_search     TEXT,
                joined_at       TEXT DEFAULT (datetime('now')),
                updated_at      TEXT DEFAULT (datetime('now'))
            );

            CREATE TABLE IF NOT EXISTS search_logs (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                telegram_id     INTEGER NOT NULL,
                query           TEXT NOT NULL,
                results_count   INTEGER DEFAULT 0,
                duration_ms     INTEGER DEFAULT 0,
                searched_at     TEXT DEFAULT (datetime('now')),
                FOREIGN KEY (telegram_id) REFERENCES users(telegram_id)
            );

            CREATE INDEX IF NOT EXISTS idx_users_telegram_id ON users(telegram_id);
            CREATE INDEX IF NOT EXISTS idx_logs_telegram_id ON search_logs(telegram_id);
            CREATE INDEX IF NOT EXISTS idx_logs_searched_at ON search_logs(searched_at);
        """)
    logger.info("✅ تم تهيئة قاعدة البيانات بنجاح")


# ===== عمليات المستخدمين =====

def get_or_create_user(telegram_id: int, username: str = None, full_name: str = None) -> dict:
    """جلب المستخدم أو إنشاؤه تلقائياً عند أول زيارة"""
    with get_db() as conn:
        user = conn.execute(
            "SELECT * FROM users WHERE telegram_id = ?", (telegram_id,)
        ).fetchone()

        if user is None:
            conn.execute(
                """INSERT INTO users (telegram_id, username, full_name)
                   VALUES (?, ?, ?)""",
                (telegram_id, username, full_name)
            )
            user = conn.execute(
                "SELECT * FROM users WHERE telegram_id = ?", (telegram_id,)
            ).fetchone()
            logger.info(f"👤 مستخدم جديد: {telegram_id} ({full_name})")
        else:
            # تحديث البيانات الأساسية عند كل زيارة
            conn.execute(
                """UPDATE users SET username=?, full_name=?, updated_at=datetime('now')
                   WHERE telegram_id=?""",
                (username, full_name, telegram_id)
            )

        return dict(user)


def get_user(telegram_id: int) -> dict | None:
    """جلب بيانات مستخدم معين"""
    with get_db() as conn:
        row = conn.execute(
            "SELECT * FROM users WHERE telegram_id = ?", (telegram_id,)
        ).fetchone()
        return dict(row) if row else None


def set_user_status(telegram_id: int, status: str) -> bool:
    """تغيير حالة المستخدم (free/premium/banned)"""
    with get_db() as conn:
        cur = conn.execute(
            "UPDATE users SET status=?, updated_at=datetime('now') WHERE telegram_id=?",
            (status, telegram_id)
        )
        return cur.rowcount > 0


def get_all_users(limit: int = 100, offset: int = 0) -> list:
    """جلب قائمة المستخدمين مع إمكانية التصفح"""
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM users ORDER BY joined_at DESC LIMIT ? OFFSET ?",
            (limit, offset)
        ).fetchall()
        return [dict(r) for r in rows]


def get_stats() -> dict:
    """إحصائيات شاملة للأدمن"""
    with get_db() as conn:
        total    = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        free     = conn.execute("SELECT COUNT(*) FROM users WHERE status='free'").fetchone()[0]
        premium  = conn.execute("SELECT COUNT(*) FROM users WHERE status='premium'").fetchone()[0]
        banned   = conn.execute("SELECT COUNT(*) FROM users WHERE status='banned'").fetchone()[0]
        searches = conn.execute("SELECT COUNT(*) FROM search_logs").fetchone()[0]
        today_s  = conn.execute(
            "SELECT COUNT(*) FROM search_logs WHERE date(searched_at)=date('now')"
        ).fetchone()[0]
        avg_dur  = conn.execute(
            "SELECT AVG(duration_ms) FROM search_logs WHERE searched_at > datetime('now','-1 day')"
        ).fetchone()[0] or 0

        return {
            "total_users": total,
            "free_users": free,
            "premium_users": premium,
            "banned_users": banned,
            "total_searches": searches,
            "today_searches": today_s,
            "avg_search_ms": round(avg_dur, 1),
        }


def log_search(telegram_id: int, query: str, results_count: int, duration_ms: int):
    """تسجيل كل عملية بحث في السجلات"""
    with get_db() as conn:
        conn.execute(
            """INSERT INTO search_logs (telegram_id, query, results_count, duration_ms)
               VALUES (?, ?, ?, ?)""",
            (telegram_id, query, results_count, duration_ms)
        )
        conn.execute(
            """UPDATE users SET search_count=search_count+1, last_search=datetime('now')
               WHERE telegram_id=?""",
            (telegram_id,)
        )


def get_user_search_count_today(telegram_id: int) -> int:
    """عدد عمليات البحث للمستخدم اليوم"""
    with get_db() as conn:
        return conn.execute(
            """SELECT COUNT(*) FROM search_logs
               WHERE telegram_id=? AND date(searched_at)=date('now')""",
            (telegram_id,)
        ).fetchone()[0]
