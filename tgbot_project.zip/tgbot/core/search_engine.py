"""
core/search_engine.py - محرك البحث عالي الأداء للملفات الضخمة
"""

import os
import time
import shutil
import asyncio
import logging
import tempfile
from pathlib import Path
from config import (
    DATA_FILE, RAMDISK_PATH, USE_RIPGREP,
    FREE_RESULTS_LIMIT, PREMIUM_RESULTS_LIMIT,
    SEARCH_TIMEOUT
)

logger = logging.getLogger(__name__)

# ===== الكشف عن الأدوات المتاحة =====
HAS_RIPGREP = shutil.which("rg") is not None
HAS_GREP    = shutil.which("grep") is not None


def get_search_file_path() -> str:
    """
    يحدد مسار الملف المُستخدم للبحث:
    1. إن وُجد RAM disk ومُفعّل → يستخدمه (الأسرع)
    2. وإلا يستخدم الملف الأصلي
    """
    ramdisk_file = os.path.join(RAMDISK_PATH, "bigfile.txt")
    if os.path.exists(ramdisk_file):
        logger.debug("⚡ استخدام RAM disk للبحث")
        return ramdisk_file

    if os.path.exists(DATA_FILE):
        return DATA_FILE

    raise FileNotFoundError(f"ملف البيانات غير موجود: {DATA_FILE}")


def _build_ripgrep_cmd(query: str, filepath: str, limit: int | None) -> list[str]:
    """بناء أمر ripgrep - الأسرع والأكثر احترافية"""
    cmd = [
        "rg",
        "--no-filename",          # بدون اسم الملف في النتيجة
        "--no-line-number",       # بدون أرقام الأسطر
        "--case-insensitive",     # بحث غير حساس لحالة الأحرف
        "--fixed-strings",        # بحث حرفي (ليس regex) لمنع حقن الأوامر
        "--text",                 # معاملة الملف كنص حتى لو ثنائي
        "--max-count=1",          # حد واحد لكل سطر (لتجنب التكرار)
    ]

    if limit:
        cmd += ["--max-total-count", str(limit)]

    cmd += [query, filepath]
    return cmd


def _build_grep_cmd(query: str, filepath: str, limit: int | None) -> list[str]:
    """بناء أمر grep - بديل احتياطي"""
    cmd = ["grep", "-i", "-F", "--text"]

    if limit:
        cmd += ["-m", str(limit)]

    cmd += [query, filepath]
    return cmd


async def search_in_file(
    query: str,
    is_premium: bool = False
) -> dict:
    """
    تنفيذ البحث بشكل غير متزامن في الملف الكبير.

    Returns:
        dict: {
            "results": list[str],
            "count": int,
            "duration_ms": int,
            "truncated": bool,
            "tool_used": str
        }
    """
    start_time = time.time()
    limit = None if is_premium else FREE_RESULTS_LIMIT

    try:
        filepath = get_search_file_path()
    except FileNotFoundError as e:
        logger.error(str(e))
        return {"error": str(e), "results": [], "count": 0, "duration_ms": 0}

    # اختيار أداة البحث
    if USE_RIPGREP and HAS_RIPGREP:
        cmd = _build_ripgrep_cmd(query, filepath, limit)
        tool = "ripgrep"
    elif HAS_GREP:
        cmd = _build_grep_cmd(query, filepath, limit)
        tool = "grep"
    else:
        # بحث Python الاحتياطي (أبطأ لكن يعمل دائماً)
        return await _python_search(query, filepath, limit, start_time)

    logger.info(f"🔍 بحث بـ {tool}: '{query}' | مميز: {is_premium}")

    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            limit=50 * 1024 * 1024  # 50MB buffer
        )

        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(),
                timeout=SEARCH_TIMEOUT
            )
        except asyncio.TimeoutError:
            proc.kill()
            await proc.communicate()
            logger.warning(f"⏰ انتهت مهلة البحث: '{query}'")
            return {
                "error": "انتهت مهلة البحث (60 ثانية). حاول بحثاً أكثر تحديداً.",
                "results": [], "count": 0, "duration_ms": int((time.time()-start_time)*1000)
            }

        # ripgrep يُعيد 0=وجد نتائج، 1=لا نتائج، 2=خطأ
        if proc.returncode == 2:
            err_msg = stderr.decode("utf-8", errors="replace").strip()
            logger.error(f"خطأ في {tool}: {err_msg}")
            return {"error": f"خطأ في البحث: {err_msg}", "results": [], "count": 0, "duration_ms": 0}

        raw_lines = stdout.decode("utf-8", errors="replace").splitlines()
        results   = [line.strip() for line in raw_lines if line.strip()]

        truncated = bool(limit and len(results) >= limit)
        duration  = int((time.time() - start_time) * 1000)

        logger.info(f"✅ نتائج: {len(results)} | وقت: {duration}ms")

        return {
            "results": results,
            "count": len(results),
            "duration_ms": duration,
            "truncated": truncated,
            "tool_used": tool,
            "error": None,
        }

    except Exception as e:
        logger.exception(f"خطأ غير متوقع في البحث: {e}")
        return {"error": f"خطأ داخلي: {str(e)}", "results": [], "count": 0, "duration_ms": 0}


async def _python_search(query: str, filepath: str, limit: int | None, start_time: float) -> dict:
    """بحث Python احتياطي - يقرأ الملف سطراً سطراً دون تحميله كاملاً"""
    results = []
    query_lower = query.lower()

    def _blocking_search():
        found = []
        with open(filepath, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                if query_lower in line.lower():
                    found.append(line.strip())
                    if limit and len(found) >= limit:
                        break
        return found

    loop = asyncio.get_event_loop()
    results = await loop.run_in_executor(None, _blocking_search)

    duration = int((time.time() - start_time) * 1000)
    return {
        "results": results,
        "count": len(results),
        "duration_ms": duration,
        "truncated": bool(limit and len(results) >= limit),
        "tool_used": "python-fallback",
        "error": None,
    }


async def write_results_to_file(results: list[str], query: str) -> str:
    """
    كتابة النتائج في ملف TXT مؤقت وإعادة مساره.
    يُحذف الملف بعد إرسال التيليغرام له.
    """
    tmp = tempfile.NamedTemporaryFile(
        mode="w",
        suffix=".txt",
        prefix=f"search_{query[:20]}_",
        delete=False,
        encoding="utf-8"
    )
    header = (
        f"نتائج البحث عن: {query}\n"
        f"عدد النتائج: {len(results)}\n"
        f"{'='*50}\n\n"
    )
    tmp.write(header)
    tmp.write("\n".join(results))
    tmp.close()
    return tmp.name


def get_file_info() -> dict:
    """معلومات ملف البيانات للأدمن"""
    info = {"path": DATA_FILE, "exists": False}
    try:
        path = Path(DATA_FILE)
        if path.exists():
            stat = path.stat()
            size_gb = stat.st_size / (1024 ** 3)
            info.update({
                "exists": True,
                "size_bytes": stat.st_size,
                "size_gb": round(size_gb, 2),
                "size_human": f"{size_gb:.2f} GB" if size_gb >= 1 else f"{stat.st_size / (1024**2):.1f} MB",
                "search_tool": "ripgrep" if (USE_RIPGREP and HAS_RIPGREP) else ("grep" if HAS_GREP else "python"),
                "ramdisk_active": os.path.exists(os.path.join(RAMDISK_PATH, "bigfile.txt")),
            })
    except Exception as e:
        info["error"] = str(e)
    return info
