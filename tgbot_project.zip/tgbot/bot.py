"""
bot.py - نقطة الدخول الرئيسية للبوت
"""

import logging
import asyncio
from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    filters,
)

from config import BOT_TOKEN
from core.database import init_db
from handlers.main_handlers import cmd_start, handle_callback, handle_message

# ===== إعداد السجلات =====
logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    level=logging.INFO,
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("bot.log", encoding="utf-8"),
    ]
)
# تخفيف سجلات مكتبة تيليغرام
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("telegram").setLevel(logging.WARNING)
logger = logging.getLogger(__name__)


def create_app() -> Application:
    """بناء وإعداد تطبيق البوت"""
    app = (
        Application.builder()
        .token(BOT_TOKEN)
        .concurrent_updates(True)       # معالجة متزامنة للطلبات
        .build()
    )

    # ===== تسجيل المعالجات =====
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CallbackQueryHandler(handle_callback))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    return app


async def post_init(app: Application):
    """تُنفَّذ بعد تهيئة البوت مباشرةً"""
    logger.info("🤖 البوت يعمل الآن...")
    bot_info = await app.bot.get_me()
    logger.info(f"✅ @{bot_info.username} | ID: {bot_info.id}")


def main():
    """الدالة الرئيسية لتشغيل البوت"""
    logger.info("🚀 بدء تشغيل البوت...")

    # تهيئة قاعدة البيانات
    init_db()

    # إنشاء التطبيق
    app = create_app()
    app.post_init = post_init

    logger.info("🔁 بدء Polling...")
    app.run_polling(
        allowed_updates=Update.ALL_TYPES,
        drop_pending_updates=True,       # تجاهل الرسائل القديمة عند الإعادة
    )


if __name__ == "__main__":
    main()
