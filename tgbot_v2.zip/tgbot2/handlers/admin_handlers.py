"""handlers/admin_handlers.py"""
import logging
from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode

from config import ADMIN_ID
from core.database import get_stats, get_all_users, get_user, set_status
from core.search_engine import file_info
from utils.keyboards import admin_menu, back_admin
from utils.helpers import fmt_num, fmt_ms

logger = logging.getLogger(__name__)


async def show_admin(q):
    st = get_stats()
    await q.edit_message_text(
        f"🛠 *لوحة الأدمن*\n\n"
        f"👥 المستخدمون: {fmt_num(st['total'])}\n"
        f"⭐ مميزون: {fmt_num(st['premium'])}\n"
        f"🚫 محظورون: {fmt_num(st['banned'])}\n"
        f"🔍 بحوث اليوم: {fmt_num(st['today'])}\n\n"
        f"اختر إجراءً 👇",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=admin_menu()
    )


async def handle_admin_cb(update: Update, ctx: ContextTypes.DEFAULT_TYPE, data: str):
    q  = update.callback_query
    tid = q.from_user.id
    if tid != ADMIN_ID:
        return

    if data == "admin_panel":
        await show_admin(q)

    elif data == "adm_users":
        users = get_all_users(20)
        em = {"free": "🆓", "premium": "⭐", "banned": "🚫"}
        lines = ["📋 *آخر 20 مستخدم:*\n"]
        for u in users:
            name = (u["full_name"] or "مجهول")[:18]
            lines.append(f"{em.get(u['status'],'?')} `{u['telegram_id']}` {name} ({u['total_searches']} بحث)")
        await q.edit_message_text("\n".join(lines), parse_mode=ParseMode.MARKDOWN, reply_markup=back_admin())

    elif data == "adm_file":
        fi = file_info()
        if not fi["exists"]:
            text = f"❌ الملف غير موجود\n`{fi['path']}`"
        else:
            text = (
                f"📁 *معلومات الملف*\n\n"
                f"📂 `{fi['path']}`\n"
                f"💾 الحجم: {fi['size_human']}\n"
                f"🛠 الأداة: {fi['tool']}\n"
                f"⚡ RAM Disk: {'✅' if fi.get('ramdisk') else '❌'}"
            )
        await q.edit_message_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=back_admin())

    elif data in ("adm_promote", "adm_demote", "adm_ban", "adm_unban"):
        labels = {
            "adm_promote": "⭐ ترقية مستخدم",
            "adm_demote":  "🔽 إلغاء الترقية",
            "adm_ban":     "🚫 حظر مستخدم",
            "adm_unban":   "✅ رفع الحظر",
        }
        ctx.user_data["adm_state"] = data
        await q.edit_message_text(
            f"{labels[data]}\n\nأرسل ID التيليغرام للمستخدم:",
            reply_markup=back_admin()
        )


async def handle_admin_input(update: Update, ctx: ContextTypes.DEFAULT_TYPE, state: str, text: str):
    tid = update.effective_user.id
    if tid != ADMIN_ID:
        return
    ctx.user_data.pop("adm_state", None)

    try:
        target = int(text.strip())
    except ValueError:
        await update.message.reply_text("❌ أرسل ID رقمي صحيح.", reply_markup=back_admin())
        return

    if target == ADMIN_ID:
        await update.message.reply_text("⚠️ لا يمكن تعديل حساب الأدمن.", reply_markup=back_admin())
        return

    user = get_user(target)
    if not user:
        await update.message.reply_text(
            f"❌ لا يوجد مستخدم بهذا الـ ID: `{target}`",
            parse_mode=ParseMode.MARKDOWN, reply_markup=back_admin()
        )
        return

    mapping = {
        "adm_promote": ("premium", "⭐ تمت الترقية"),
        "adm_demote":  ("free",    "🔽 تم إلغاء الترقية"),
        "adm_ban":     ("banned",  "🚫 تم الحظر"),
        "adm_unban":   ("free",    "✅ تم رفع الحظر"),
    }
    new_status, label = mapping[state]
    set_status(target, new_status)
    name = user.get("full_name") or str(target)
    await update.message.reply_text(
        f"{label}\n\n👤 {name}\n🆔 `{target}`\n📌 الحالة: {new_status}",
        parse_mode=ParseMode.MARKDOWN, reply_markup=back_admin()
    )
