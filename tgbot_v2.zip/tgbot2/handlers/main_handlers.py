"""handlers/main_handlers.py"""
import os, logging
from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode

from config import ADMIN_ID, FREE_DAILY_LIMIT, FREE_RESULTS_LIMIT
from core.database import (
    get_or_create_user, get_stats, log_search,
    get_daily_count, increment_daily
)
from core.search_engine import search, save_results, file_info
from utils.keyboards import main_menu, cancel, search_again, back_main
from utils.helpers import check_cooldown, validate_query, fmt_num, fmt_ms

logger = logging.getLogger(__name__)
WAIT_SEARCH = "wait_search"


def _user_data(update: Update):
    u = update.effective_user
    return u.id, u.username or "", u.full_name or "مجهول"


async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    tid, uname, fname = _user_data(update)
    user = get_or_create_user(tid, uname, fname)

    if user["status"] == "banned":
        await update.message.reply_text("🚫 أنت محظور.")
        return

    is_admin   = tid == ADMIN_ID
    is_premium = user["status"] == "premium"
    badge = "⭐ مميز" if is_premium else "🆓 مجاني"

    if is_premium:
        limit_txt = "نتائج غير محدودة ♾️"
        daily_txt = "بحوث غير محدودة ♾️"
    else:
        daily_used = get_daily_count(tid)
        remaining  = max(0, FREE_DAILY_LIMIT - daily_used)
        limit_txt  = fmt_num(FREE_RESULTS_LIMIT) + " نتيجة"
        daily_txt  = f"{remaining}/{FREE_DAILY_LIMIT} بحوث اليوم"

    text = (
        f"👋 *مرحباً {fname}!*\n\n"
        f"🔍 *بوت البحث الاحترافي*\n\n"
        f"👤 الحساب: {badge}\n"
        f"📊 النتائج: {limit_txt}\n"
        f"🗓 {daily_txt}\n\n"
        f"اختر من القائمة 👇"
    )
    await update.message.reply_text(
        text, parse_mode=ParseMode.MARKDOWN,
        reply_markup=main_menu(is_admin=is_admin, is_premium=is_premium)
    )


async def handle_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q   = update.callback_query
    await q.answer()
    tid = q.from_user.id
    data = q.data

    user = get_or_create_user(tid, q.from_user.username, q.from_user.full_name)

    if user["status"] == "banned" and data != "main_menu":
        await q.edit_message_text("🚫 أنت محظور.")
        return

    is_admin   = tid == ADMIN_ID
    is_premium = user["status"] == "premium"

    if data == "main_menu":
        if is_premium:
            daily_txt = "بحوث غير محدودة ♾️"
        else:
            remaining = max(0, FREE_DAILY_LIMIT - get_daily_count(tid))
            daily_txt = f"{remaining}/{FREE_DAILY_LIMIT} بحوث متبقية اليوم"

        badge = "⭐ مميز" if is_premium else "🆓 مجاني"
        await q.edit_message_text(
            f"🏠 *القائمة الرئيسية*\n\n"
            f"👤 {badge} | 🗓 {daily_txt}\n\nاختر 👇",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=main_menu(is_admin=is_admin, is_premium=is_premium)
        )

    elif data == "search":
        ctx.user_data["state"] = WAIT_SEARCH
        if is_premium:
            note = "نتائج غير محدودة ♾️"
        else:
            remaining = max(0, FREE_DAILY_LIMIT - get_daily_count(tid))
            note = f"لديك {remaining} بحث متبقٍ اليوم"
        await q.edit_message_text(
            f"🔍 *وضع البحث*\n\n{note}\n\n✏️ أرسل نص البحث الآن:",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=cancel()
        )

    elif data == "my_account":
        daily_used = get_daily_count(tid)
        if is_premium:
            daily_txt = "غير محدود ♾️"
        else:
            remaining = max(0, FREE_DAILY_LIMIT - daily_used)
            daily_txt = f"{remaining}/{FREE_DAILY_LIMIT} متبقٍ اليوم"

        badge = "⭐ مميز" if is_premium else "🆓 مجاني"
        text = (
            f"👤 *حسابك*\n\n"
            f"🆔 ID: `{tid}`\n"
            f"📛 الاسم: {user['full_name'] or '—'}\n"
            f"🏷 الحالة: {badge}\n"
            f"🗓 البحوث اليوم: {daily_txt}\n"
            f"🔢 إجمالي البحوث: {fmt_num(user['total_searches'])}\n"
            f"📅 الانضمام: {(user['joined_at'] or '')[:10]}"
        )
        await q.edit_message_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=back_main())

    elif data == "stats":
        st = get_stats()
        fi = file_info()
        size = fi.get("size_human", "غير معروف") if fi["exists"] else "الملف غير موجود"
        text = (
            f"📊 *إحصائيات*\n\n"
            f"👥 المستخدمون: {fmt_num(st['total'])}\n"
            f"⭐ المميزون: {fmt_num(st['premium'])}\n"
            f"🔍 إجمالي البحوث: {fmt_num(st['searches'])}\n"
            f"📅 بحوث اليوم: {fmt_num(st['today'])}\n"
            f"⚡ متوسط الوقت: {fmt_ms(st['avg_ms'])}\n"
            f"📁 حجم الملف: {size}"
        )
        await q.edit_message_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=back_main())

    elif data == "premium_info":
        if is_premium:
            text = (
                "⭐ *أنت مستخدم مميز!*\n\n"
                "✅ نتائج غير محدودة\n"
                "✅ بحوث يومية غير محدودة\n"
                "✅ أولوية في المعالجة\n\n"
                "شكراً لدعمك 🙏"
            )
        else:
            text = (
                "⭐ *الخطة المميزة*\n\n"
                f"🆓 *المجاني:*\n"
                f"• {FREE_DAILY_LIMIT} بحوث يومياً فقط\n"
                f"• حد {fmt_num(FREE_RESULTS_LIMIT)} نتيجة\n"
                f"• العداد يُصفَّر منتصف الليل 🕛\n\n"
                f"⭐ *المميز:*\n"
                f"• بحوث غير محدودة ♾️\n"
                f"• نتائج غير محدودة ♾️\n\n"
                f"📩 للترقية تواصل مع الأدمن"
            )
        await q.edit_message_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=back_main())

    elif data == "admin_panel" and is_admin:
        from handlers.admin_handlers import show_admin
        await show_admin(q)

    elif data.startswith("adm_") and is_admin:
        from handlers.admin_handlers import handle_admin_cb
        await handle_admin_cb(update, ctx, data)

    elif data.startswith("adm_") and not is_admin:
        await q.answer("⛔ غير مصرح لك.", show_alert=True)


async def handle_message(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    tid   = update.effective_user.id
    text  = (update.message.text or "").strip()
    user  = get_or_create_user(tid, update.effective_user.username, update.effective_user.full_name)

    if user["status"] == "banned":
        await update.message.reply_text("🚫 أنت محظور.")
        return

    state = ctx.user_data.get("state")

    if state == WAIT_SEARCH:
        await _do_search(update, ctx, text, user)
        return

    adm_state = ctx.user_data.get("adm_state")
    if adm_state and tid == ADMIN_ID:
        from handlers.admin_handlers import handle_admin_input
        await handle_admin_input(update, ctx, adm_state, text)
        return

    is_premium = user["status"] == "premium"
    await update.message.reply_text(
        "استخدم الأزرار أو /start للبدء.",
        reply_markup=main_menu(is_admin=(tid == ADMIN_ID), is_premium=is_premium)
    )


async def _do_search(update: Update, ctx: ContextTypes.DEFAULT_TYPE, query_text: str, user: dict):
    tid        = update.effective_user.id
    is_premium = user["status"] == "premium"
    ctx.user_data.pop("state", None)

    # cooldown
    rem = check_cooldown(tid)
    if rem > 0:
        await update.message.reply_text(f"⏳ انتظر {rem} ثانية قبل البحث مجدداً.")
        return

    # العداد اليومي للمجانيين
    if not is_premium:
        daily_used = get_daily_count(tid)
        if daily_used >= FREE_DAILY_LIMIT:
            await update.message.reply_text(
                f"⛔ *انتهت بحوثك اليومية المجانية!*\n\n"
                f"لديك {FREE_DAILY_LIMIT} بحوث/يوم مجاناً.\n"
                f"🕛 يُعاد العداد عند منتصف الليل.\n\n"
                f"⭐ للحصول على بحوث غير محدودة، يمكنك الترقية للحساب المميز.",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=back_main()
            )
            return

    # التحقق من النص
    ok, err = validate_query(query_text)
    if not ok:
        await update.message.reply_text(err, reply_markup=cancel())
        return

    wait = await update.message.reply_text(
        f"🔍 جارٍ البحث عن: *{query_text}*\n⏳ الرجاء الانتظار...",
        parse_mode=ParseMode.MARKDOWN
    )

    result = await search(query_text, is_premium=is_premium)

    # تسجيل البحث + زيادة العداد
    log_search(tid, query_text, result["count"], result["duration_ms"])
    if not is_premium:
        increment_daily(tid)

    try:
        await wait.delete()
    except Exception:
        pass

    if result["error"]:
        await update.message.reply_text(
            f"❌ *خطأ في البحث*\n\n{result['error']}",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=search_again()
        )
        return

    count = result["count"]
    dur   = fmt_ms(result["duration_ms"])

    if count == 0:
        await update.message.reply_text(
            f"🔍 البحث عن: *{query_text}*\n\n😔 لا توجد نتائج.\n⏱ الوقت: {dur}",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=search_again()
        )
        return

    # حساب البحوث المتبقية
    if not is_premium:
        new_used  = get_daily_count(tid)
        remaining = max(0, FREE_DAILY_LIMIT - new_used)
        daily_note = f"\n🗓 بحوث متبقية اليوم: {remaining}/{FREE_DAILY_LIMIT}"
    else:
        daily_note = ""

    trunc_note = ""
    if result["truncated"] and not is_premium:
        trunc_note = (
            f"\n\n⚠️ *تم الاقتصار على {fmt_num(FREE_RESULTS_LIMIT)} نتيجة*\n"
            f"ترقّ للمميز للحصول على نتائج غير محدودة ⭐"
        )

    caption = (
        f"✅ *نتائج البحث*\n\n"
        f"🔎 الكلمة: `{query_text}`\n"
        f"📊 النتائج: {fmt_num(count)}\n"
        f"⏱ الوقت: {dur}\n"
        f"🛠 الأداة: {result['tool']}"
        f"{daily_note}"
        f"{trunc_note}"
    )

    fp = await save_results(result["results"], query_text)
    try:
        with open(fp, "rb") as f:
            await update.message.reply_document(
                document=f,
                filename=f"results_{query_text[:25]}.txt",
                caption=caption,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=search_again()
            )
    finally:
        os.unlink(fp)
