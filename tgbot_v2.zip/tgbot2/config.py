"""
config.py - إعدادات البوت
"""
import os

BOT_TOKEN  = os.getenv("BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")
ADMIN_ID   = int(os.getenv("ADMIN_ID", "123456789"))

DATA_FILE    = os.getenv("DATA_FILE", "/data/bigfile.txt")
RAMDISK_PATH = os.getenv("RAMDISK_PATH", "/mnt/ramdisk")
DB_PATH      = os.getenv("DB_PATH", "bot.db")

# حدود البحث
FREE_DAILY_LIMIT    = 2      # عدد البحوث المجانية يومياً
FREE_RESULTS_LIMIT  = 1000   # حد النتائج للمجانيين
PREMIUM_RESULTS_LIMIT = None # بلا حدود

SEARCH_TIMEOUT  = 60
SEARCH_COOLDOWN = 5
MAX_QUERY_LEN   = 200
