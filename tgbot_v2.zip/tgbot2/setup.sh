#!/bin/bash
# setup.sh - تثبيت البوت على VPS
set -e
echo "🚀 تثبيت بوت البحث..."

sudo apt-get update -q
sudo apt-get install -y python3 python3-pip python3-venv ripgrep

echo "✅ ripgrep: $(rg --version | head -1)"

sudo mkdir -p /opt/tgbot
sudo cp -r ./* /opt/tgbot/
sudo chown -R ubuntu:ubuntu /opt/tgbot

cd /opt/tgbot
python3 -m venv venv
venv/bin/pip install --upgrade pip -q
venv/bin/pip install -r requirements.txt -q
echo "✅ المكتبات مثبتة"

read -p "BOT_TOKEN: " bot_token
read -p "ADMIN_ID: "  admin_id
read -p "مسار الملف [/data/bigfile.txt]: " data_file
data_file=${data_file:-/data/bigfile.txt}

sed -i "s|YOUR_TOKEN_HERE|$bot_token|g" /opt/tgbot/tgbot.service
sed -i "s|YOUR_ADMIN_ID|$admin_id|g"    /opt/tgbot/tgbot.service
sed -i "s|/data/bigfile.txt|$data_file|g" /opt/tgbot/tgbot.service

sudo cp /opt/tgbot/tgbot.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable tgbot
sudo systemctl start tgbot

echo ""
echo "✅ البوت يعمل الآن!"
echo "sudo journalctl -u tgbot -f  ← للسجلات"
