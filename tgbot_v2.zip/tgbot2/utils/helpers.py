"""utils/helpers.py"""
import re, time
from config import SEARCH_COOLDOWN, MAX_QUERY_LEN

_cooldowns: dict[int, float] = {}
_BAD = re.compile(r'[`$\\|><;&\n\r]')


def check_cooldown(tid: int) -> float:
    now = time.time()
    rem = SEARCH_COOLDOWN - (now - _cooldowns.get(tid, 0))
    if rem > 0:
        return round(rem, 1)
    _cooldowns[tid] = now
    return 0


def validate_query(q: str) -> tuple[bool, str]:
    q = q.strip()
    if not q:
        return False, "❌ نص البحث فارغ."
    if len(q) < 2:
        return False, "❌ نص البحث قصير جداً (حرفان على الأقل)."
    if len(q) > MAX_QUERY_LEN:
        return False, f"❌ نص البحث طويل (الحد {MAX_QUERY_LEN} حرف)."
    if _BAD.search(q):
        return False, "❌ يحتوي على أحرف غير مسموح بها."
    return True, ""


def fmt_num(n: int) -> str:
    return f"{n:,}"


def fmt_ms(ms: int) -> str:
    return f"{ms}ms" if ms < 1000 else f"{ms/1000:.1f}s"
