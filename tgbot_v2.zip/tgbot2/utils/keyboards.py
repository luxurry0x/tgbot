"""utils/keyboards.py"""
from telegram import InlineKeyboardButton as Btn, InlineKeyboardMarkup as Mkp


def main_menu(is_admin=False, is_premium=False) -> Mkp:
    rows = [
        [Btn("🔍 بحث", callback_data="search"),
         Btn("⭐ المميز", callback_data="premium_info")],
        [Btn("📊 إحصائيات", callback_data="stats"),
         Btn("👤 حسابي", callback_data="my_account")],
    ]
    if is_admin:
        rows.append([Btn("🛠 لوحة الأدمن", callback_data="admin_panel")])
    return Mkp(rows)


def admin_menu() -> Mkp:
    return Mkp([
        [Btn("👥 المستخدمون", callback_data="adm_users"),
         Btn("📁 الملف", callback_data="adm_file")],
        [Btn("⭐ ترقية", callback_data="adm_promote"),
         Btn("🔽 إلغاء ترقية", callback_data="adm_demote")],
        [Btn("🚫 حظر", callback_data="adm_ban"),
         Btn("✅ رفع حظر", callback_data="adm_unban")],
        [Btn("🔙 رجوع", callback_data="main_menu")],
    ])


def back_main() -> Mkp:
    return Mkp([[Btn("🏠 الرئيسية", callback_data="main_menu")]])


def back_admin() -> Mkp:
    return Mkp([[Btn("🔙 الأدمن", callback_data="admin_panel"),
                 Btn("🏠 الرئيسية", callback_data="main_menu")]])


def cancel() -> Mkp:
    return Mkp([[Btn("❌ إلغاء", callback_data="main_menu")]])


def search_again() -> Mkp:
    return Mkp([[Btn("🔍 بحث مجدداً", callback_data="search"),
                 Btn("🏠 الرئيسية", callback_data="main_menu")]])
