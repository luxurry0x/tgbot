"""
core/database.py - قاعدة البيانات مع عداد يومي
"""
import sqlite3
import logging
from contextlib import contextmanager
from config import DB_PATH

logger = logging.getLogger(__name__)


@contextmanager
def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    with get_db() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                telegram_id     INTEGER PRIMARY KEY,
                username        TEXT,
                full_name       TEXT,
                status          TEXT DEFAULT 'free',
                total_searches  INTEGER DEFAULT 0,
                daily_searches  INTEGER DEFAULT 0,
                last_search_date TEXT DEFAULT '',
                joined_at       TEXT DEFAULT (date('now')),
                last_seen       TEXT DEFAULT (datetime('now'))
            );

            CREATE TABLE IF NOT EXISTS search_logs (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                telegram_id  INTEGER,
                query        TEXT,
                results      INTEGER DEFAULT 0,
                duration_ms  INTEGER DEFAULT 0,
                searched_at  TEXT DEFAULT (datetime('now'))
            );

            CREATE INDEX IF NOT EXISTS idx_users_tid ON users(telegram_id);
            CREATE INDEX IF NOT EXISTS idx_logs_tid  ON search_logs(telegram_id);
        """)
    logger.info("✅ قاعدة البيانات جاهزة")


# ===== المستخدمون =====

def get_or_create_user(tid: int, username: str = None, full_name: str = None) -> dict:
    with get_db() as conn:
        row = conn.execute("SELECT * FROM users WHERE telegram_id=?", (tid,)).fetchone()
        if row is None:
            conn.execute(
                "INSERT INTO users (telegram_id, username, full_name) VALUES (?,?,?)",
                (tid, username, full_name)
            )
            row = conn.execute("SELECT * FROM users WHERE telegram_id=?", (tid,)).fetchone()
            logger.info(f"👤 مستخدم جديد: {tid} - {full_name}")
        else:
            conn.execute(
                "UPDATE users SET username=?, full_name=?, last_seen=datetime('now') WHERE telegram_id=?",
                (username, full_name, tid)
            )
        return dict(row)


def get_user(tid: int) -> dict | None:
    with get_db() as conn:
        row = conn.execute("SELECT * FROM users WHERE telegram_id=?", (tid,)).fetchone()
        return dict(row) if row else None


def set_status(tid: int, status: str) -> bool:
    with get_db() as conn:
        cur = conn.execute("UPDATE users SET status=? WHERE telegram_id=?", (status, tid))
        return cur.rowcount > 0


def get_all_users(limit=20) -> list:
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM users ORDER BY joined_at DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(r) for r in rows]


def get_stats() -> dict:
    with get_db() as conn:
        total   = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        free    = conn.execute("SELECT COUNT(*) FROM users WHERE status='free'").fetchone()[0]
        premium = conn.execute("SELECT COUNT(*) FROM users WHERE status='premium'").fetchone()[0]
        banned  = conn.execute("SELECT COUNT(*) FROM users WHERE status='banned'").fetchone()[0]
        searches= conn.execute("SELECT COUNT(*) FROM search_logs").fetchone()[0]
        today   = conn.execute(
            "SELECT COUNT(*) FROM search_logs WHERE date(searched_at)=date('now')"
        ).fetchone()[0]
        avg_ms  = conn.execute(
            "SELECT AVG(duration_ms) FROM search_logs WHERE searched_at > datetime('now','-1 day')"
        ).fetchone()[0] or 0
        return dict(total=total, free=free, premium=premium, banned=banned,
                    searches=searches, today=today, avg_ms=round(avg_ms))


# ===== العداد اليومي =====

def get_daily_count(tid: int) -> int:
    """إرجاع عدد البحوث اليوم — يُصفَّر تلقائياً إن كان التاريخ مختلفاً"""
    with get_db() as conn:
        row = conn.execute(
            "SELECT daily_searches, last_search_date FROM users WHERE telegram_id=?", (tid,)
        ).fetchone()
        if not row:
            return 0
        from datetime import date
        today = str(date.today())
        if row["last_search_date"] != today:
            # يوم جديد → صفّر العداد
            conn.execute(
                "UPDATE users SET daily_searches=0, last_search_date=? WHERE telegram_id=?",
                (today, tid)
            )
            return 0
        return row["daily_searches"]


def increment_daily(tid: int):
    """زيادة عداد اليوم + الإجمالي + تحديث التاريخ"""
    from datetime import date
    today = str(date.today())
    with get_db() as conn:
        conn.execute(
            """UPDATE users SET
                daily_searches  = daily_searches + 1,
                total_searches  = total_searches + 1,
                last_search_date = ?
               WHERE telegram_id=?""",
            (today, tid)
        )


def log_search(tid: int, query: str, results: int, duration_ms: int):
    with get_db() as conn:
        conn.execute(
            "INSERT INTO search_logs (telegram_id,query,results,duration_ms) VALUES (?,?,?,?)",
            (tid, query, results, duration_ms)
        )
