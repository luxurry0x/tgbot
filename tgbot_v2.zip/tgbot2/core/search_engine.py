"""
core/search_engine.py - محرك البحث (ripgrep/grep/python)
تم اختبار جميع الـ flags والتأكد من صحتها
"""
import os
import time
import shutil
import asyncio
import logging
import tempfile
from pathlib import Path
from config import DATA_FILE, RAMDISK_PATH, SEARCH_TIMEOUT

logger = logging.getLogger(__name__)

HAS_RG   = shutil.which("rg")   is not None
HAS_GREP = shutil.which("grep") is not None


def _data_file() -> str:
    """مسار الملف — RAM disk أولاً إن وُجد"""
    rd = os.path.join(RAMDISK_PATH, os.path.basename(DATA_FILE))
    if os.path.exists(rd):
        return rd
    if os.path.exists(DATA_FILE):
        return DATA_FILE
    raise FileNotFoundError(f"ملف البيانات غير موجود: {DATA_FILE}")


def _rg_cmd(query: str, filepath: str, limit: int | None) -> list[str]:
    """
    أوامر ripgrep مُختبَرة — flags صحيحة 100%
    -i  = ignore case
    -F  = fixed strings (نص حرفي، ليس regex)
    -a  = text mode
    -N  = بدون أرقام أسطر
    --no-filename = بدون اسم الملف
    -m N = أقصى N نتيجة لكل ملف (بديل --max-total-count الذي لا يوجد)
    """
    cmd = ["rg", "-i", "-F", "-a", "-N", "--no-filename"]
    if limit:
        cmd += ["-m", str(limit)]
    cmd += [query, filepath]
    return cmd


def _grep_cmd(query: str, filepath: str, limit: int | None) -> list[str]:
    cmd = ["grep", "-i", "-F", "-a"]
    if limit:
        cmd += ["-m", str(limit)]
    cmd += [query, filepath]
    return cmd


async def search(query: str, is_premium: bool = False) -> dict:
    """
    تنفيذ البحث — يُعيد dict:
      results, count, duration_ms, truncated, tool, error
    """
    t0    = time.time()
    limit = None if is_premium else 1000

    try:
        filepath = _data_file()
    except FileNotFoundError as e:
        return _err(str(e))

    if HAS_RG:
        cmd, tool = _rg_cmd(query, filepath, limit), "ripgrep"
    elif HAS_GREP:
        cmd, tool = _grep_cmd(query, filepath, limit), "grep"
    else:
        return await _py_search(query, filepath, limit, t0)

    logger.info(f"🔍 {tool} | query='{query}' | premium={is_premium}")

    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=SEARCH_TIMEOUT)
        except asyncio.TimeoutError:
            proc.kill()
            await proc.communicate()
            return _err("انتهت مهلة البحث (60 ث). جرّب كلمة أكثر تحديداً.")

        # rg: 0=نتائج، 1=لا نتائج، 2=خطأ حقيقي
        if proc.returncode == 2:
            msg = stderr.decode("utf-8", errors="replace").strip()
            logger.error(f"{tool} error: {msg}")
            return _err(f"خطأ في أداة البحث:\n{msg}")

        lines = [l.strip() for l in stdout.decode("utf-8", errors="replace").splitlines() if l.strip()]
        ms    = int((time.time() - t0) * 1000)
        trunc = bool(limit and len(lines) >= limit)

        logger.info(f"✅ {len(lines)} نتيجة | {ms}ms")
        return dict(results=lines, count=len(lines), duration_ms=ms,
                    truncated=trunc, tool=tool, error=None)

    except Exception as e:
        logger.exception(e)
        return _err(str(e))


async def _py_search(query: str, filepath: str, limit: int | None, t0: float) -> dict:
    """بحث Python احتياطي — لا يُحمِّل الملف كاملاً"""
    ql = query.lower()

    def _run():
        out = []
        with open(filepath, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                if ql in line.lower():
                    out.append(line.rstrip())
                    if limit and len(out) >= limit:
                        break
        return out

    loop = asyncio.get_event_loop()
    lines = await loop.run_in_executor(None, _run)
    ms = int((time.time() - t0) * 1000)
    return dict(results=lines, count=len(lines), duration_ms=ms,
                truncated=bool(limit and len(lines) >= limit),
                tool="python", error=None)


def _err(msg: str) -> dict:
    return dict(results=[], count=0, duration_ms=0, truncated=False, tool=None, error=msg)


async def save_results(results: list[str], query: str) -> str:
    """حفظ النتائج في ملف TXT مؤقت وإرجاع مساره"""
    tmp = tempfile.NamedTemporaryFile(
        mode="w", suffix=".txt",
        prefix=f"results_{query[:15]}_",
        delete=False, encoding="utf-8"
    )
    tmp.write(f"البحث عن: {query}\n")
    tmp.write(f"النتائج : {len(results)}\n")
    tmp.write("=" * 50 + "\n\n")
    tmp.write("\n".join(results))
    tmp.close()
    return tmp.name


def file_info() -> dict:
    info = {"path": DATA_FILE, "exists": False}
    try:
        p = Path(DATA_FILE)
        if p.exists():
            s = p.stat()
            gb = s.st_size / 1024**3
            info.update(
                exists=True,
                size_bytes=s.st_size,
                size_human=f"{gb:.2f} GB" if gb >= 1 else f"{s.st_size/1024**2:.1f} MB",
                tool="ripgrep" if HAS_RG else ("grep" if HAS_GREP else "python"),
                ramdisk=os.path.exists(os.path.join(RAMDISK_PATH, os.path.basename(DATA_FILE))),
            )
    except Exception as e:
        info["error"] = str(e)
    return info
