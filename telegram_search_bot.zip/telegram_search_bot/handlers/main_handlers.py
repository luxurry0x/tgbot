import os
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler

from config import ADMIN_ID, FREE_LIMIT, TMP_DIR, DATA_FILE_PATH
from database import db_manager
from utils.search_engine import search_file, validate_query
from utils.parser import extract_combos, format_results_header

logger = logging.getLogger(__name__)

AWAITING_QUERY = 1
AWAITING_TARGET_USER = 2
AWAITING_ACTION = 3

os.makedirs(TMP_DIR, exist_ok=True)


def main_menu_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔍 Search", callback_data="search"),
         InlineKeyboardButton("👤 Profile", callback_data="profile")],
        [InlineKeyboardButton("🛠 Admin Panel", callback_data="admin")],
    ])


def search_result_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📄 Raw Results", callback_data="mode_raw"),
         InlineKeyboardButton("🔐 Combo Only", callback_data="mode_combo")],
        [InlineKeyboardButton("🏠 Main Menu", callback_data="main_menu")],
    ])


def admin_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📊 Stats", callback_data="admin_stats"),
         InlineKeyboardButton("👥 Manage User", callback_data="admin_manage")],
        [InlineKeyboardButton("🏠 Main Menu", callback_data="main_menu")],
    ])


def user_action_keyboard(target_id: int, current_status: str):
    buttons = []
    if current_status != "Premium":
        buttons.append(InlineKeyboardButton("⭐ Set Premium", callback_data=f"setstatus_{target_id}_Premium"))
    if current_status != "Free":
        buttons.append(InlineKeyboardButton("🔓 Set Free", callback_data=f"setstatus_{target_id}_Free"))
    if current_status != "Banned":
        buttons.append(InlineKeyboardButton("🚫 Ban", callback_data=f"setstatus_{target_id}_Banned"))
    buttons.append(InlineKeyboardButton("🔙 Back", callback_data="admin"))
    return InlineKeyboardMarkup([buttons])


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    await db_manager.register_user(user.id, user.username or "", user.first_name or "")
    text = (
        f"⚡ *Welcome, {user.first_name}!*\n\n"
        "This bot lets you search through large databases at high speed.\n"
        "Use the menu below to get started."
    )
    await update.message.reply_text(text, parse_mode="Markdown", reply_markup=main_menu_keyboard())


async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data

    if data == "main_menu":
        await query.edit_message_text("🏠 *Main Menu*", parse_mode="Markdown", reply_markup=main_menu_keyboard())
    elif data == "profile":
        await show_profile(update, context)
    elif data == "search":
        await prompt_search(update, context)
        return AWAITING_QUERY
    elif data == "admin":
        await show_admin_panel(update, context)
    elif data == "admin_stats":
        await show_admin_stats(update, context)
    elif data == "admin_manage":
        await prompt_manage_user(update, context)
        return AWAITING_TARGET_USER
    elif data.startswith("setstatus_"):
        await handle_set_status(update, context, data)
    elif data in ("mode_raw", "mode_combo"):
        await deliver_results(update, context, mode=data)


async def show_profile(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    record = await db_manager.get_user(user.id)
    status = record["status"] if record else "Unknown"
    searches = record["searches"] if record else 0
    limit_text = "Unlimited" if status == "Premium" else f"{FREE_LIMIT:,}"
    text = (
        f"👤 *Your Profile*\n\n"
        f"🆔 ID: `{user.id}`\n"
        f"📛 Name: {user.first_name}\n"
        f"🏷 Status: *{status}*\n"
        f"🔍 Searches: {searches:,}\n"
        f"📦 Result Limit: {limit_text}"
    )
    await update.callback_query.edit_message_text(
        text, parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🏠 Main Menu", callback_data="main_menu")]])
    )


async def prompt_search(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.edit_message_text(
        "🔍 *Search*\n\nPlease type your query:\n_(letters, digits, @, . - _ + allowed)_",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ Cancel", callback_data="main_menu")]])
    )
    return AWAITING_QUERY


async def receive_query(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    raw_query = update.message.text.strip()

    if not validate_query(raw_query):
        await update.message.reply_text(
            "⚠️ Invalid characters in query. Only letters, digits, and `@.-_+` are allowed.",
            parse_mode="Markdown"
        )
        return AWAITING_QUERY

    record = await db_manager.get_user(user.id)
    if not record or record["status"] == "Banned":
        await update.message.reply_text("🚫 You are banned from using this bot.")
        return ConversationHandler.END

    limit: int | None = None if record["status"] == "Premium" else FREE_LIMIT

    status_msg = await update.message.reply_text(f"⏳ Searching for `{raw_query}`...", parse_mode="Markdown")

    try:
        results = await search_file(raw_query, limit=limit)
    except ValueError:
        await status_msg.edit_text("⚠️ Invalid query. Please try again.")
        return AWAITING_QUERY
    except Exception as e:
        logger.error(f"Search failed: {e}")
        await status_msg.edit_text("❌ Search engine error. Please try again later.")
        return ConversationHandler.END

    await db_manager.increment_search_count(user.id)

    if not results:
        await status_msg.edit_text(f"🔍 No results found for `{raw_query}`.", parse_mode="Markdown")
        return ConversationHandler.END

    context.user_data["results"] = results
    context.user_data["query"] = raw_query
    await status_msg.delete()

    limit_note = f"_(limited to {FREE_LIMIT:,})_" if limit else "_(unlimited)_"
    await update.message.reply_text(
        f"✅ Found *{len(results):,}* results for `{raw_query}` {limit_note}\n\nChoose your output format:",
        parse_mode="Markdown",
        reply_markup=search_result_keyboard()
    )
    return ConversationHandler.END


async def deliver_results(update: Update, context: ContextTypes.DEFAULT_TYPE, mode: str):
    query_text = context.user_data.get("query", "unknown")
    results: list[str] = context.user_data.get("results", [])

    if not results:
        await update.callback_query.edit_message_text("⚠️ No cached results. Please search again.")
        return

    if mode == "mode_combo":
        output_lines = extract_combos(results)
        mode_label = "Combo"
    else:
        output_lines = results
        mode_label = "Raw"

    header = format_results_header(query_text, len(output_lines), mode_label)
    file_content = header + "\n".join(output_lines)

    safe_query = "".join(c for c in query_text if c.isalnum() or c in "-_@.")
    file_path = os.path.join(TMP_DIR, f"{safe_query}_{mode_label}.txt")

    try:
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(file_content)
        with open(file_path, "rb") as f:
            await context.bot.send_document(
                chat_id=update.effective_chat.id,
                document=f,
                filename=os.path.basename(file_path),
                caption=f"📦 *{mode_label}* results for `{query_text}` — {len(output_lines):,} entries",
                parse_mode="Markdown"
            )
    except Exception as e:
        logger.error(f"Failed to deliver results: {e}")
        await update.callback_query.edit_message_text("❌ Failed to generate result file.")
    finally:
        if os.path.exists(file_path):
            os.remove(file_path)

    await update.callback_query.edit_message_text("✅ Results sent!", reply_markup=main_menu_keyboard())


async def show_admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        await update.callback_query.edit_message_text("🚫 Unauthorized.")
        return
    await update.callback_query.edit_message_text(
        "🛠 *Admin Panel*\n\nChoose an action:",
        parse_mode="Markdown",
        reply_markup=admin_keyboard()
    )


async def show_admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return
    user_count = await db_manager.get_user_count()
    try:
        file_size = os.path.getsize(DATA_FILE_PATH)
        file_info = f"{file_size / (1024 ** 3):.2f} GB"
    except OSError:
        file_info = "File not found"
    text = (
        f"📊 *Bot Statistics*\n\n"
        f"👥 Total Users: *{user_count:,}*\n"
        f"🗄 Data File Size: *{file_info}*\n"
        f"📂 File Path: `{DATA_FILE_PATH}`"
    )
    await update.callback_query.edit_message_text(
        text, parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="admin")]])
    )


async def prompt_manage_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return
    await update.callback_query.edit_message_text(
        "👤 *Manage User*\n\nSend the Telegram user ID to manage:",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ Cancel", callback_data="admin")]])
    )
    return AWAITING_TARGET_USER


async def receive_target_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return ConversationHandler.END
    raw = update.message.text.strip()
    if not raw.isdigit():
        await update.message.reply_text("⚠️ Please send a valid numeric Telegram ID.")
        return AWAITING_TARGET_USER
    target_id = int(raw)
    record = await db_manager.get_user(target_id)
    if not record:
        await update.message.reply_text(f"❌ User `{target_id}` not found.", parse_mode="Markdown")
        return ConversationHandler.END
    context.user_data["target_user"] = record
    text = (
        f"👤 *User Info*\n\n"
        f"🆔 ID: `{record['user_id']}`\n"
        f"📛 Name: {record['first_name']}\n"
        f"🏷 Status: *{record['status']}*\n"
        f"🔍 Searches: {record['searches']:,}"
    )
    await update.message.reply_text(
        text, parse_mode="Markdown",
        reply_markup=user_action_keyboard(target_id, record["status"])
    )
    return ConversationHandler.END


async def handle_set_status(update: Update, context: ContextTypes.DEFAULT_TYPE, data: str):
    if update.effective_user.id != ADMIN_ID:
        return
    _, target_id_str, new_status = data.split("_", 2)
    target_id = int(target_id_str)
    await db_manager.set_user_status(target_id, new_status)
    await update.callback_query.edit_message_text(
        f"✅ User `{target_id}` status set to *{new_status}*.",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Admin Panel", callback_data="admin")]])
    )
