import os

BOT_TOKEN = os.getenv("BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")
ADMIN_ID = int(os.getenv("ADMIN_ID", "123456789"))

# Absolute path to your large TXT data file
DATA_FILE_PATH = os.getenv("DATA_FILE_PATH", "/data/database.txt")

# Search result limits
FREE_LIMIT = 1000
PREMIUM_LIMIT = None  # None = unlimited

# Temporary output directory for result files
TMP_DIR = "/tmp/bot_results"
