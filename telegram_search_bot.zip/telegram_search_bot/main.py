import logging
import asyncio
from telegram import Update
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    ConversationHandler,
    filters,
)

from config import BOT_TOKEN
from database.db_manager import init_db
from handlers.main_handlers import (
    start, button_handler, receive_query, receive_target_user,
    AWAITING_QUERY, AWAITING_TARGET_USER,
)

logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)


async def post_init(application):
    await init_db()
    logger.info("Bot initialized and database ready.")


def main():
    app = (
        ApplicationBuilder()
        .token(BOT_TOKEN)
        .post_init(post_init)
        .build()
    )

    search_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(receive_query, pattern="^search$")],
        states={
            AWAITING_QUERY: [MessageHandler(filters.TEXT & ~filters.COMMAND, receive_query)],
        },
        fallbacks=[CommandHandler("start", start)],
        per_message=False,
    )

    admin_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(receive_target_user, pattern="^admin_manage$")],
        states={
            AWAITING_TARGET_USER: [MessageHandler(filters.TEXT & ~filters.COMMAND, receive_target_user)],
        },
        fallbacks=[CommandHandler("start", start)],
        per_message=False,
    )

    app.add_handler(CommandHandler("start", start))
    app.add_handler(search_conv)
    app.add_handler(admin_conv)
    app.add_handler(CallbackQueryHandler(button_handler))

    logger.info("Bot is running...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
