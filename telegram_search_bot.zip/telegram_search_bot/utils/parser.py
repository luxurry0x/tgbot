import re
import logging

logger = logging.getLogger(__name__)

COMBO_REGEX = re.compile(
    r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}:[^\s]+"
    r"|[a-zA-Z0-9._%+\-]{3,}:[^\s]{4,}"
)


def extract_combos(lines: list[str]) -> list[str]:
    seen = set()
    combos = []
    for line in lines:
        line = line.strip()
        if not line:
            continue
        match = COMBO_REGEX.search(line)
        if match:
            combo = match.group(0).strip()
            if combo not in seen:
                seen.add(combo)
                combos.append(combo)
    return combos


def format_results_header(query: str, count: int, mode: str) -> str:
    return (
        f"# ══════════════════════════════\n"
        f"# Query  : {query}\n"
        f"# Results: {count}\n"
        f"# Mode   : {mode.upper()}\n"
        f"# ══════════════════════════════\n\n"
    )
