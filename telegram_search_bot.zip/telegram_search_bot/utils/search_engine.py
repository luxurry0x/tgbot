import asyncio
import logging
import shutil
import re
from config import DATA_FILE_PATH

logger = logging.getLogger(__name__)

SAFE_QUERY_RE = re.compile(r"^[a-zA-Z0-9@.\-_+]+$")


def validate_query(query: str) -> bool:
    return bool(SAFE_QUERY_RE.match(query))


async def search_file(query: str, limit: int | None) -> list[str]:
    if not validate_query(query):
        raise ValueError("Query contains invalid characters.")

    if shutil.which("rg"):
        cmd = ["rg", "--no-filename", "--no-line-number", "-i", query, DATA_FILE_PATH]
    elif shutil.which("grep"):
        cmd = ["grep", "-i", query, DATA_FILE_PATH]
    else:
        raise EnvironmentError("Neither ripgrep nor grep is available on this system.")

    results = []

    try:
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        async for raw_line in process.stdout:
            line = raw_line.decode("utf-8", errors="replace").strip()
            if line:
                results.append(line)
                if limit is not None and len(results) >= limit:
                    process.kill()
                    break

        await process.wait()

    except Exception as e:
        logger.error(f"Search error: {e}")
        raise

    return results
